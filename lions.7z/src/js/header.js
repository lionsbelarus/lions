export default class User {
  constructor(name) {
    console.log('user')
  }
};