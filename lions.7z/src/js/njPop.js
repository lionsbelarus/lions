'use strict';

// export default function njPop() {
//   console.log('njPop')
// }
console.log('njPop')